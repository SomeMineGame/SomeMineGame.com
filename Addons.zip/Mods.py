import datetime, subprocess, shutil, os, time
from os import system, name

def clear():
    if name == 'nt':
        _ = system('cls')

    else:
        _ = system('clear')

ModPath = "./Main/Mods"

def mods():
    Mod = input("What is the mod name?\n\n--> ")
    clear()
    Description = input("What is the description?\n\n--> ")
    clear()
    Usage = input("How do we use it?\n\n--> ")
    clear()
    Location = input("What is the location?\n\n--> ")
    clear()
    Link = input("What is the link?\n\n--> ")
    clear()
    dt = datetime.datetime.now()
    Time = dt.strftime("%B %d, %Y at %I:%M %p")
    open(f"{ModPath}/{Mod}.html", "x")
    with open(f"{ModPath}/{Mod}.html", "r+") as f:
        f.write(f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{Mod}</title>
    <link rel="icon" type="image/x-icon" href="/assets/Logo.png">
    <link rel="stylesheet" href="/css/main.css">
    <link rel="stylesheet" href="./../css/mods/mods.css">
</head>
<body>
    <ul id="homeul">
        <li><a href="./../Home">Home</a></li>
        <li><a href="./../Commands">Discord-Commands</a></li>
        <li><a href="./../Mods">Mods</a></li>
        <li><a class="active" href="./../Mods">Mods</a></li>
        <li><a href="./../Datapacks">Datapacks</a></li>
        <li><a href="./../Lawbook">Lawbook</a></li>
        <li><a href="./../Server-News">News</a></li>
        <li><a href="http://map.someminegame.com/#">Live Map</a><li>
        <li><a href="https://someminegame.com">Main Page</a><li>
        <li style="padding: 10px 16px; float: right; color: orange">SMG-SMP Wiki</li>
    </ul>
    <h1 style="background-color: yellow;font-size: 24px; color: black">SomeMineGame.com IS STILL UNDER CONSTRUCTION. EXPECT BUGS.</h1>
    <div class="maingrid">
        <div class="info">
            <h1><img src="../assets/mods/{Mod}.png" alt="{Mod} Logo" style="font-size:1vw;"><br>What Is {Mod}?</h1>
            <h2>{Description}<br><br></h2>
            <h1>How Do We Use {Mod}?</h1>
            <h2>{Usage}<br><br></h2>
            <h1>How Does {Mod} Work?</h1>
            <video src="../assets/mods/videos/{Mod}.mp4" controls="controls" controlsList="nodownload" type="video/mp4"></video><p><br></p>
            <h1>Where Can You Get {Mod}?</h1>
            <h2>{Mod} is free on their {Location} page. You can click the link below.<br><br><a target="_blank" href="{Link}">{Mod} on {Location}</a><br><br></h2>
        </div>
    </div>
</body>
<footer>
    <ul style="padding: 3px 10px">
        <li class="left">Site Created By: SomeMineGame</li>
        <li class="right">Page Last Edited: {Time}</li>
    </ul>
</footer>
</html>""")
    mods()
mods()